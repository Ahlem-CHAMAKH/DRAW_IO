-- ============================================================
--  TRIGGERS / SYNONYMS / PACKAGE BODIES / GRANTS EXTRACTION
--  Schema: MOAMALAT
--  Run as DBA or user with SELECT on ALL_* views
-- ============================================================

SET LONG          2000000
SET LONGCHUNKSIZE 2000000
SET LINESIZE      32767
SET PAGESIZE      0
SET TRIMSPOOL     ON
SET TRIMOUT       ON
SET FEEDBACK      OFF
SET VERIFY        OFF
SET ECHO          OFF
SET HEADING       ON
SET COLSEP        '|'

SPOOL extract_triggers_synonyms_grants_MOAMALAT.txt

-- ============================================================
-- 1. TRIGGERS
--    TRIGGER_NAME | TABLE_NAME | TRIGGER_TYPE | TRIGGERING_EVENT | STATUS | TRIGGER_BODY
-- ============================================================
PROMPT [TRIGGERS]
SELECT
    t.trigger_name,
    t.table_name,
    t.trigger_type,
    t.triggering_event,
    t.status,
    t.trigger_body
FROM all_triggers t
WHERE t.owner = 'MOAMALAT'
ORDER BY t.table_name, t.trigger_name;

-- ============================================================
-- 2. SYNONYMS
--    SYNONYM_NAME | TABLE_OWNER | TABLE_NAME | DB_LINK
-- ============================================================
PROMPT [SYNONYMS]
SELECT
    s.synonym_name,
    s.table_owner,
    s.table_name,
    s.db_link
FROM all_synonyms s
WHERE s.owner = 'MOAMALAT'
ORDER BY s.synonym_name;

-- ============================================================
-- 3. PACKAGE BODIES — source code line by line
--    OBJECT_NAME | LINE | TEXT
-- ============================================================
PROMPT [PACKAGE_BODIES]
SELECT
    s.name,
    s.line,
    s.text
FROM all_source s
WHERE s.owner = 'MOAMALAT'
  AND s.type  = 'PACKAGE BODY'
ORDER BY s.name, s.line;

-- ============================================================
-- 4. OBJECT GRANTS — privileges granted ON objects owned by MOAMALAT
--    TABLE_NAME | PRIVILEGE | GRANTEE | GRANTABLE
-- ============================================================
PROMPT [OBJECT_GRANTS]
SELECT
    tp.table_name   AS object_name,
    tp.privilege,
    tp.grantee,
    tp.grantable,
    tp.hierarchy
FROM all_tab_privs tp
WHERE tp.owner = 'MOAMALAT'
ORDER BY tp.table_name, tp.privilege, tp.grantee;

-- ============================================================
-- 5. SYSTEM PRIVILEGES granted TO MOAMALAT
--    PRIVILEGE | ADMIN_OPTION
-- ============================================================
PROMPT [SYSTEM_PRIVILEGES]
SELECT
    privilege,
    admin_option
FROM dba_sys_privs
WHERE grantee = 'MOAMALAT'
ORDER BY privilege;

-- ============================================================
-- 6. ROLE PRIVILEGES granted TO MOAMALAT
-- ============================================================
PROMPT [ROLE_PRIVILEGES]
SELECT
    granted_role,
    admin_option,
    default_role
FROM dba_role_privs
WHERE grantee = 'MOAMALAT'
ORDER BY granted_role;

SPOOL OFF
PROMPT Done. Output saved to: extract_triggers_synonyms_grants_MOAMALAT.txt
