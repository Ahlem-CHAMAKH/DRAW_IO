-- ============================================================
--  FULL DDL — MISSING TABLES FROM MOAMALAT_REVAMP
--  Produces ready-to-run DDL for each missing table:
--    1. CREATE TABLE (with inline NOT NULL constraints)
--    2. ALTER TABLE ... ADD CONSTRAINT (PK, UK, FK, CHECK)
--    3. CREATE INDEX (standalone indexes only)
--
--  IMPORTANT: Run this connected as DBA or a user with:
--    - SELECT on DBA_TABLES, DBA_CONSTRAINTS, DBA_INDEXES
--    - EXECUTE on DBMS_METADATA
--
--  The CONSTRAINTS_AS_ALTER param ensures constraints come out
--  as separate ALTER TABLE statements — safe execution order:
--  all tables first, then FKs won't fail on missing references.
-- ============================================================

-- Fix truncation
SET LONG          2000000
SET LONGCHUNKSIZE 2000000
SET LINESIZE      32767
SET PAGESIZE      0
SET TRIMSPOOL     ON
SET TRIMOUT       ON
SET FEEDBACK      OFF
SET VERIFY        OFF
SET ECHO          OFF
SET HEADING       OFF

-- ============================================================
-- STEP 1 — Configure DDL transform params (session-level)
-- ============================================================
BEGIN
    -- Strip environment-specific noise
    DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM, 'STORAGE',            FALSE);
    DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM, 'TABLESPACE',          FALSE);
    DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM, 'SEGMENT_ATTRIBUTES',  FALSE);
    -- Emit a semicolon after each statement
    DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM, 'SQLTERMINATOR',       TRUE);
    -- Include PK / UK / FK / CHECK as ALTER TABLE statements
    DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM, 'CONSTRAINTS',         TRUE);
    DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM, 'REF_CONSTRAINTS',     TRUE);
    -- Key setting: emit constraints as ALTER TABLE (not inline)
    -- This allows you to run CREATE TABLEs first, then ALTER TABLEs
    -- so FK references to other tables don't fail
    DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM, 'CONSTRAINTS_AS_ALTER',TRUE);
END;
/

SPOOL ddl_missing_tables_full.sql

-- ============================================================
-- STEP 2 — CREATE TABLE + ALTER TABLE (PK / UK / FK / CHECK)
--           for every table in REVAMP missing in MOAMALAT
-- ============================================================
PROMPT -- ============================================================
PROMPT -- [STEP 2] CREATE TABLE + CONSTRAINTS
PROMPT --          Run all of these before the indexes below
PROMPT -- ============================================================

SELECT DBMS_METADATA.GET_DDL('TABLE', table_name, 'MOAMALAT_REVAMP')
FROM all_tables
WHERE owner = 'MOAMALAT_REVAMP'
  AND table_name NOT IN (
      SELECT table_name FROM all_tables WHERE owner = 'MOAMALAT'
  )
ORDER BY table_name;

-- ============================================================
-- STEP 3 — CREATE INDEX
--           Only standalone indexes (not backing a PK or UK —
--           those were already created by ALTER TABLE above)
-- ============================================================
PROMPT -- ============================================================
PROMPT -- [STEP 3] CREATE INDEX (standalone indexes only)
PROMPT --          Run after all CREATE TABLE statements above
PROMPT -- ============================================================

SELECT DBMS_METADATA.GET_DDL('INDEX', index_name, 'MOAMALAT_REVAMP')
FROM all_indexes
WHERE owner      = 'MOAMALAT_REVAMP'
  -- Only for tables missing in MOAMALAT
  AND table_name NOT IN (
      SELECT table_name FROM all_tables WHERE owner = 'MOAMALAT'
  )
  -- Exclude constraint-backed indexes (PK / UK) — already handled in STEP 2
  AND index_name NOT IN (
      SELECT constraint_name
      FROM   all_constraints
      WHERE  owner           = 'MOAMALAT_REVAMP'
        AND  constraint_type IN ('P', 'U')
  )
ORDER BY table_name, index_name;

SPOOL OFF
PROMPT
PROMPT Done. Full DDL saved to: ddl_missing_tables_full.sql
PROMPT
PROMPT Recommended execution order in MOAMALAT:
PROMPT   1. Run all CREATE TABLE statements
PROMPT   2. Run all ALTER TABLE ... ADD CONSTRAINT (PK/UK first, then FK)
PROMPT   3. Run all CREATE INDEX statements
